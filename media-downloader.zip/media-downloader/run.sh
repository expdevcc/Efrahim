#!/bin/bash
# Media Downloader - Google Cloud Shell Setup
set -e

echo "=== Media Downloader Setup ==="

# Install system deps
echo "[1/4] ffmpeg yüklənir..."
sudo apt-get install -y ffmpeg -q

# Python deps
echo "[2/4] Python paketləri yüklənir..."
pip install -r requirements.txt -q

# Create downloads dir
mkdir -p downloads

echo "[3/4] yt-dlp yenilənir..."
pip install -U yt-dlp -q

echo "[4/4] Server işə salınır... (port 8080)"
echo ""
echo ">>> Google Cloud Shell-də 'Web Preview' -> port 8080 açın <<<"
echo ""
uvicorn main:app --host 0.0.0.0 --port 8080 --reload
