import yt_dlp
import os
import asyncio
from pathlib import Path

DOWNLOAD_DIR = Path("downloads")
DOWNLOAD_DIR.mkdir(exist_ok=True)


def get_formats(url: str) -> dict:
    """Extract available formats without downloading."""
    ydl_opts = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "nocheckcertificate": True,
    }
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            return parse_formats(info)
    except yt_dlp.utils.DownloadError as e:
        raise ValueError(f"URL oxunmadı: {str(e)}")
    except Exception as e:
        raise ValueError(f"Xəta: {str(e)}")


def parse_formats(info: dict) -> dict:
    """Parse formats into structured response."""
    title = info.get("title", "media")
    thumbnail = info.get("thumbnail", "")
    duration = info.get("duration")
    ext = info.get("ext", "")

    # Check if it's an image (no duration, image ext)
    is_image = ext in ("jpg", "jpeg", "png", "webp", "gif") or (
        not duration and info.get("_type") == "image"
    )

    formats = info.get("formats", [])

    video_formats = []
    audio_formats = []

    seen_video = set()
    seen_audio = set()

    for f in formats:
        fid = f.get("format_id", "")
        vcodec = f.get("vcodec", "none")
        acodec = f.get("acodec", "none")
        height = f.get("height")
        abr = f.get("abr")
        filesize = f.get("filesize") or f.get("filesize_approx")

        # Video+audio combined or video-only (we'll merge with audio)
        if vcodec != "none" and height:
            label = f"{height}p"
            if label not in seen_video:
                seen_video.add(label)
                video_formats.append({
                    "id": fid,
                    "label": label,
                    "height": height,
                    "filesize": filesize,
                })

        # Audio only
        if vcodec == "none" and acodec != "none" and abr:
            label = f"{int(abr)}kbps"
            if label not in seen_audio:
                seen_audio.add(label)
                audio_formats.append({
                    "id": fid,
                    "label": label,
                    "abr": abr,
                    "filesize": filesize,
                })

    # Sort
    video_formats.sort(key=lambda x: x["height"], reverse=True)
    audio_formats.sort(key=lambda x: x["abr"], reverse=True)

    # Fallback if no formats parsed
    if not video_formats and not is_image:
        video_formats = [{"id": "best", "label": "Best", "height": 9999, "filesize": None}]
    if not audio_formats and not is_image:
        audio_formats = [{"id": "bestaudio", "label": "Best", "abr": 9999, "filesize": None}]

    return {
        "title": title,
        "thumbnail": thumbnail,
        "duration": duration,
        "is_image": is_image,
        "video_formats": video_formats,
        "audio_formats": audio_formats,
    }


async def download_media(url: str, mode: str, format_id: str) -> Path:
    """
    mode: 'video' | 'audio' | 'image'
    format_id: e.g. '137', 'best', '140', 'bestaudio'
    Returns path to downloaded file.
    """
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _download_sync, url, mode, format_id)


def _download_sync(url: str, mode: str, format_id: str) -> Path:
    outtmpl = str(DOWNLOAD_DIR / "%(title).60s_%(id)s.%(ext)s")

    if mode == "audio":
        ydl_opts = {
            "format": format_id if format_id not in ("best", "bestaudio") else "bestaudio/best",
            "outtmpl": outtmpl,
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }],
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
        }
    elif mode == "image":
        ydl_opts = {
            "format": "best",
            "outtmpl": outtmpl,
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "writethumbnail": True,
            "skip_download": True,
        }
    else:  # video
        if format_id in ("best", "bestvideo"):
            fmt = "bestvideo+bestaudio/best"
        else:
            fmt = f"{format_id}+bestaudio/best"

        ydl_opts = {
            "format": fmt,
            "outtmpl": outtmpl,
            "merge_output_format": "mp4",
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
        }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        # Find the output file
        filename = ydl.prepare_filename(info)
        # For audio, extension changes to mp3
        if mode == "audio":
            filename = Path(filename).with_suffix(".mp3")
        elif mode == "image":
            # thumbnail file
            base = Path(filename).stem
            for ext in ("jpg", "jpeg", "png", "webp"):
                candidate = DOWNLOAD_DIR / f"{base}.{ext}"
                if candidate.exists():
                    return candidate
        path = Path(filename)
        if path.exists():
            return path
        # fallback: find newest file in downloads
        files = sorted(DOWNLOAD_DIR.iterdir(), key=lambda f: f.stat().st_mtime, reverse=True)
        if files:
            return files[0]
        raise FileNotFoundError("Fayl tapılmadı")
