from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import asyncio
import os
import time
from pathlib import Path
from downloader import get_formats, download_media, DOWNLOAD_DIR

app = FastAPI(title="Media Downloader")
app.mount("/static", StaticFiles(directory="static"), name="static")


class FormatRequest(BaseModel):
    url: str


class DownloadRequest(BaseModel):
    url: str
    mode: str   # video | audio | image
    format_id: str


@app.get("/")
async def index():
    return FileResponse("static/index.html")


@app.post("/api/formats")
async def api_formats(req: FormatRequest):
    try:
        loop = asyncio.get_event_loop()
        data = await loop.run_in_executor(None, get_formats, req.url)
        return JSONResponse(data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Server xətası: {str(e)}")


@app.post("/api/download")
async def api_download(req: DownloadRequest, background_tasks: BackgroundTasks):
    if req.mode not in ("video", "audio", "image"):
        raise HTTPException(status_code=400, detail="Mode yanlışdır")

    try:
        file_path = await download_media(req.url, req.mode, req.format_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Yükləmə xətası: {str(e)}")

    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Fayl tapılmadı")

    # Clean up after sending
    background_tasks.add_task(cleanup_file, file_path)

    return FileResponse(
        path=str(file_path),
        filename=file_path.name,
        media_type="application/octet-stream",
    )


def cleanup_file(path: Path):
    """Delete file after it's been sent."""
    time.sleep(30)
    try:
        os.remove(path)
    except Exception:
        pass


# Periodically clean old downloads (>1 hour)
@app.on_event("startup")
async def startup_cleanup():
    DOWNLOAD_DIR.mkdir(exist_ok=True)
